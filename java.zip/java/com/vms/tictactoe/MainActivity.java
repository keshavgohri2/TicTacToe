package com.vms.tictactoe;

import android.os.Bundle;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import com.vms.tictactoe.databinding.ActivityMainBinding;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    ActivityMainBinding binding;
    private final List<int[]> combinationList = new ArrayList<>();
    private int[] boxPositions = {0, 0, 0, 0, 0, 0, 0, 0, 0}; // 9 zero
    private int playerTurn = 1;
    private int totalSelectedBoxes = 1;

    private int playerOneScore = 0; // Score for Player One
    private int playerTwoScore = 0; // Score for Player Two

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        combinationList.add(new int[]{0, 1, 2});
        combinationList.add(new int[]{3, 4, 5});
        combinationList.add(new int[]{6, 7, 8});
        combinationList.add(new int[]{0, 3, 6});
        combinationList.add(new int[]{1, 4, 7});
        combinationList.add(new int[]{2, 5, 8});
        combinationList.add(new int[]{2, 4, 6});
        combinationList.add(new int[]{0, 4, 8});

        String getPlayerOneName = getIntent().getStringExtra("playerOne");
        String getPlayerTwoName = getIntent().getStringExtra("playerTwo");

        binding.playerOneName.setText(getPlayerOneName);
        binding.playerTwoName.setText(getPlayerTwoName);

        // Initialize scores
        updateScoreDisplay();

        // Add click listeners for game boxes
        setBoxClickListeners();
    }

    private void setBoxClickListeners() {
        binding.image1.setOnClickListener(view -> handleBoxClick((ImageView) view, 0));
        binding.image2.setOnClickListener(view -> handleBoxClick((ImageView) view, 1));
        binding.image3.setOnClickListener(view -> handleBoxClick((ImageView) view, 2));
        binding.image4.setOnClickListener(view -> handleBoxClick((ImageView) view, 3));
        binding.image5.setOnClickListener(view -> handleBoxClick((ImageView) view, 4));
        binding.image6.setOnClickListener(view -> handleBoxClick((ImageView) view, 5));
        binding.image7.setOnClickListener(view -> handleBoxClick((ImageView) view, 6));
        binding.image8.setOnClickListener(view -> handleBoxClick((ImageView) view, 7));
        binding.image9.setOnClickListener(view -> handleBoxClick((ImageView) view, 8));
    }

    private void handleBoxClick(ImageView imageView, int selectedBoxPosition) {
        if (isBoxSelectable(selectedBoxPosition)) {
            performAction(imageView, selectedBoxPosition);
        }
    }

    private void performAction(ImageView imageView, int selectedBoxPosition) {
        boxPositions[selectedBoxPosition] = playerTurn;

        if (playerTurn == 1) {
            imageView.setImageResource(R.drawable.ximage);
            if (checkResults()) {
                playerOneScore++;
                updateScoreDisplay();
                showResultDialog(binding.playerOneName.getText().toString() + " is the Winner!");
            } else {
                continueGame();
            }
        } else {
            imageView.setImageResource(R.drawable.oimage);
            if (checkResults()) {
                playerTwoScore++;
                updateScoreDisplay();
                showResultDialog(binding.playerTwoName.getText().toString() + " is the Winner!");
            } else {
                continueGame();
            }
        }
    }

    private void continueGame() {
        if (totalSelectedBoxes == 9) {
            showResultDialog("Match Draw");
        } else {
            changePlayerTurn(playerTurn == 1 ? 2 : 1);
            totalSelectedBoxes++;
        }
    }

    private void showResultDialog(String message) {
        ResultDialog resultDialog = new ResultDialog(MainActivity.this, message, MainActivity.this);
        resultDialog.setCancelable(false);
        resultDialog.show();
    }

    private void updateScoreDisplay() {
        binding.txtScore1.setText(String.valueOf("Player 1: "+playerOneScore));
        binding.txtScore2.setText(String.valueOf("Player 2: "+playerTwoScore));
    }

    private void changePlayerTurn(int currentPlayerTurn) {
        playerTurn = currentPlayerTurn;
        if (playerTurn == 1) {
            binding.playerOneLayout.setBackgroundResource(R.drawable.black_border);
            binding.playerTwoLayout.setBackgroundResource(R.drawable.white_box);
        } else {
            binding.playerTwoLayout.setBackgroundResource(R.drawable.black_border);
            binding.playerOneLayout.setBackgroundResource(R.drawable.white_box);
        }
    }

    private boolean checkResults() {
        for (int[] combination : combinationList) {
            if (boxPositions[combination[0]] == playerTurn &&
                    boxPositions[combination[1]] == playerTurn &&
                    boxPositions[combination[2]] == playerTurn) {
                return true;
            }
        }
        return false;
    }

    private boolean isBoxSelectable(int boxPosition) {
        return boxPositions[boxPosition] == 0;
    }

    public void restartMatch() {
        boxPositions = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0};
        playerTurn = 1;
        totalSelectedBoxes = 1;

        binding.image1.setImageResource(R.drawable.white_box);
        binding.image2.setImageResource(R.drawable.white_box);
        binding.image3.setImageResource(R.drawable.white_box);
        binding.image4.setImageResource(R.drawable.white_box);
        binding.image5.setImageResource(R.drawable.white_box);
        binding.image6.setImageResource(R.drawable.white_box);
        binding.image7.setImageResource(R.drawable.white_box);
        binding.image8.setImageResource(R.drawable.white_box);
        binding.image9.setImageResource(R.drawable.white_box);
    }
}
